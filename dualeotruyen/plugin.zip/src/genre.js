function execute() {
        return Response.success(
[
        {
            "input": "/the-loai/manga.html",
            "title": "Manga",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/manhua.html",
            "title": "Manhua",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/manhwa.html",
            "title": "Manhwa",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/18-.html",
            "title": "18+",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/dam-my.html",
            "title": "Đam Mỹ",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/harem.html",
            "title": "Harem",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/truyen-mau.html",
            "title": "Truyện Màu",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/boylove.html",
            "title": "BoyLove",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/girllove.html",
            "title": "GirlLove",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/phieu-luu.html",
            "title": "Phiêu lưu",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/yaoi.html",
            "title": "Yaoi",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/hai-huoc.html",
            "title": "Hài Hước",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/bach-hop.html",
            "title": "Bách Hợp",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/chuyen-sinh.html",
            "title": "Chuyển Sinh",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/drama.html",
            "title": "Drama",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/hanh-dong.html",
            "title": "Hành Động",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/kich-tinh.html",
            "title": "Kịch Tính",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/co-dai.html",
            "title": "Cổ Đại",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/echi.html",
            "title": "Echi",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/hentai.html",
            "title": "Hentai",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/lang-man.html",
            "title": "Lãng Mạn",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/nguoi-thu.html",
            "title": "Người Thú",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/tinh-cam.html",
            "title": "Tình Cảm",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/yuri.html",
            "title": "Yuri",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/oneshot.html",
            "title": "Oneshot",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/doujinshi.html",
            "title": "Doujinshi",
            "script": "gen.js"
        },
        {
            "input": "/the-loai/abo.html",
            "title": "ABO",
            "script": "gen.js"
        }


]
    
    );
}