function execute(url) {
    const response = fetch(url);
    
    if (response.ok) {
        const doc = response.html();
        let data = [];
        
        doc.select('ul[class="dropdown-menu scroll-menu"] a').forEach(e => {

            data.push({
                input: e.attr("href").replace(/^https?:\/\/[^/]+/, ""),
                title: e.text().trim(),
                script: "gen.js",
            })
        })

        return Response.success(data)
    }
    return Response.error("Kiểm tra lại?")
}