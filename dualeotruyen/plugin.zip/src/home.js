function execute() {
        return Response.success(
[
        {
            "input": "/truyen-moi-cap-nhat.html",
            "title": "Truyện Mới Cập Nhập",
            "script": "gen.js"
        },
        {
            "input": "/truyen-tranh-moi.html",
            "title": "Truyện Mới",
            "script": "gen.js"
        },
        {
            "input": "/truyen-hoan-thanh.html",
            "title": "Truyện Full",
            "script": "gen.js"
        },
        {
            "input": "/top-ngay.html",
            "title": "Top Ngày",
            "script": "gen.js"
        },
        {
            "input": "/top-tuan.html",
            "title": "Top Tuần",
            "script": "gen.js"
        },
        {
            "input": "/top-thang.html",
            "title": "Top Tháng",
            "script": "gen.js"
        },
        {
            "input": "/top-nam.html",
            "title": "Top Năm",
            "script": "gen.js"
        }
]
    
    );
}