let BASE_URL = "https://ungtycomicsnay.com";
if (typeof host !== "undefined") {
    BASE_URL = host;
}