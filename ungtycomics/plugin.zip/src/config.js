let BASE_URL = "https://ungtycomicseo.com";
if (typeof host !== "undefined") {
    BASE_URL = host;
}