function execute() {
        return Response.success(
[
        {
            "input": "/truyen-tranh",
            "title": "Truyện Mới",
            "script": "gen.js"
        },
        {
            "input": "/full-tron-bo.html",
            "title": "Truyện Full",
            "script": "gen.js"
        },
        {
            "input": "/dam-my.html",
            "title": "Đam Mỹ",
            "script": "gen.js"
        },
        {
            "input": "/manhwa.html",
            "title": "Manhwa",
            "script": "gen.js"
        },
]
    
    );
}