function execute() {
        return Response.success(
[

{title: "Mới đăng",input: "/chapmoinhat/", script: "gen.js"},
{title: "Truyện hot",input: "/popular/", script: "gen.js"},
{title: "Đã hoàn",input: "/da-hoan/", script: "gen.js"},


]
    
    );
}